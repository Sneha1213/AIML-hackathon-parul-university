
let currentDate = new Date();
let currentUserEmail = '';
let events = [];
let currentEventData = null;
let selectedDate = null;
let analyticsVisible = false;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    showEmailModal();
});

// Email Modal Functions
function showEmailModal() {
    document.getElementById('emailModal').style.display = 'block';
    document.getElementById('calendarContainer').style.display = 'none';
}

function setUserEmail() {
    const email = document.getElementById('userEmail').value.trim();
    if (email && isValidEmail(email)) {
        currentUserEmail = email;
        document.getElementById('currentUserEmail').textContent = email;
        document.getElementById('emailModal').style.display = 'none';
        document.getElementById('calendarContainer').style.display = 'block';
        loadUserEvents();
        renderCalendar();
        loadAnalytics();
    } else {
        alert('Please enter a valid email address');
    }
}

function changeUser() {
    document.getElementById('userEmail').value = '';
    analyticsVisible = false;
    document.getElementById('analyticsPanel').style.display = 'none';
    document.querySelector('.content-grid').classList.remove('with-analytics');
    showEmailModal();
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Calendar Navigation
function previousMonth() {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar();
}

function nextMonth() {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar();
}

// Load user events from server
async function loadUserEvents() {
    try {
        const response = await fetch(`/api/events/user/${encodeURIComponent(currentUserEmail)}`);
        if (response.ok) {
            events = await response.json();
            renderCalendar();
            if (analyticsVisible) {
                loadAnalytics();
            }
        } else {
            console.error('Failed to load events');
        }
    } catch (error) {
        console.error('Error loading events:', error);
    }
}

// Render the calendar
function renderCalendar() {
    const monthYear = document.getElementById('monthYear');
    const calendarGrid = document.getElementById('calendarGrid');
    
    // Update month/year display
    const months = ['January', 'February', 'March', 'April', 'May', 'June',
                   'July', 'August', 'September', 'October', 'November', 'December'];
    monthYear.textContent = `${months[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
    
    // Clear existing calendar days (keep headers)
    const existingDays = calendarGrid.querySelectorAll('.calendar-day');
    existingDays.forEach(day => day.remove());
    
    // Get first day of month and number of days
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());
    
    // Generate calendar days
    for (let i = 0; i < 42; i++) {
        const day = new Date(startDate);
        day.setDate(startDate.getDate() + i);
        
        const dayElement = createDayElement(day);
        calendarGrid.appendChild(dayElement);
    }
}

function createDayElement(date) {
    const dayElement = document.createElement('div');
    dayElement.className = 'calendar-day';
    
    const isCurrentMonth = date.getMonth() === currentDate.getMonth();
    const isToday = isDateToday(date);
    
    if (!isCurrentMonth) {
        dayElement.classList.add('other-month');
    }
    
    if (isToday) {
        dayElement.classList.add('today');
    }
    
    // Day number
    const dayNumber = document.createElement('div');
    dayNumber.className = 'day-number';
    dayNumber.textContent = date.getDate();
    dayElement.appendChild(dayNumber);
    
    // Events for this day
    const dayEvents = document.createElement('div');
    dayEvents.className = 'day-events';
    
    const dayEventsFiltered = getDayEvents(date);
    dayEventsFiltered.forEach(event => {
        const eventCard = createEventCard(event);
        dayEvents.appendChild(eventCard);
    });
    
    dayElement.appendChild(dayEvents);
    
    // Click handler
    dayElement.addEventListener('click', () => showDayEvents(date));
    
    return dayElement;
}

function createEventCard(event) {
    const eventCard = document.createElement('div');
    eventCard.className = `event-card ${event.category.toLowerCase()}`;
    eventCard.textContent = event.title;
    eventCard.style.backgroundColor = event.color;
    
    eventCard.addEventListener('click', (e) => {
        e.stopPropagation();
        editEvent(event);
    });
    
    return eventCard;
}

function getDayEvents(date) {
    const categoryFilter = document.getElementById('categoryFilter').value;
    
    return events.filter(event => {
        // Create date object preserving the original date without timezone issues
        const eventDate = new Date(event.startDate);
        const checkDate = new Date(date);
        
        // Compare year, month, and day separately to avoid timezone issues
        const isSameDay = eventDate.getFullYear() === checkDate.getFullYear() &&
                         eventDate.getMonth() === checkDate.getMonth() &&
                         eventDate.getDate() === checkDate.getDate();
        
        const matchesCategory = !categoryFilter || event.category === categoryFilter;
        
        // Handle recurring events
        if (event.recurring !== 'none' && !isSameDay) {
            return isRecurringEventDate(event, date) && matchesCategory;
        }
        
        return isSameDay && matchesCategory;
    });
}

function isRecurringEventDate(event, checkDate) {
    const eventStart = new Date(event.startDate);
    const diffTime = checkDate.getTime() - eventStart.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return false;
    
    switch (event.recurring) {
        case 'daily':
            return true;
        case 'weekly':
            return diffDays % 7 === 0;
        case 'monthly':
            return eventStart.getDate() === checkDate.getDate();
        default:
            return false;
    }
}

function isDateToday(date) {
    const today = new Date();
    return date.toDateString() === today.toDateString();
}

// Event Modal Functions
function showAddEventModal(date = null) {
    selectedDate = date;
    currentEventData = null;
    
    document.getElementById('modalTitle').textContent = 'Add Event';
    document.getElementById('eventForm').reset();
    document.getElementById('eventId').value = '';
    document.getElementById('deleteBtn').style.display = 'none';
    
    if (date) {
        // Create exact date without timezone manipulation
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        
        const now = new Date();
        let hour = 9;
        let minute = 0;
        
        // If it's today and after 9 AM, start from next hour
        if (date.toDateString() === now.toDateString() && now.getHours() >= 9) {
            hour = now.getHours() + 1;
            minute = 0;
        }
        
        const startDateTime = `${year}-${month}-${day}T${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
        const endDateTime = `${year}-${month}-${day}T${String(hour + 1).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
        
        document.getElementById('eventStartDate').value = startDateTime;
        document.getElementById('eventEndDate').value = endDateTime;
    }
    
    document.getElementById('eventModal').style.display = 'block';
}

function editEvent(event) {
    currentEventData = event;
    
    document.getElementById('modalTitle').textContent = 'Edit Event';
    document.getElementById('eventId').value = event._id;
    document.getElementById('eventTitle').value = event.title;
    document.getElementById('eventDescription').value = event.description || '';
    
    // Convert to local datetime format without timezone conversion
    const startDate = new Date(event.startDate);
    const endDate = new Date(event.endDate);
    
    const startYear = startDate.getFullYear();
    const startMonth = String(startDate.getMonth() + 1).padStart(2, '0');
    const startDay = String(startDate.getDate()).padStart(2, '0');
    const startHour = String(startDate.getHours()).padStart(2, '0');
    const startMinute = String(startDate.getMinutes()).padStart(2, '0');
    
    const endYear = endDate.getFullYear();
    const endMonth = String(endDate.getMonth() + 1).padStart(2, '0');
    const endDay = String(endDate.getDate()).padStart(2, '0');
    const endHour = String(endDate.getHours()).padStart(2, '0');
    const endMinute = String(endDate.getMinutes()).padStart(2, '0');
    
    document.getElementById('eventStartDate').value = `${startYear}-${startMonth}-${startDay}T${startHour}:${startMinute}`;
    document.getElementById('eventEndDate').value = `${endYear}-${endMonth}-${endDay}T${endHour}:${endMinute}`;
    
    document.getElementById('eventCategory').value = event.category;
    document.getElementById('eventRecurring').value = event.recurring;
    document.getElementById('eventReminder').value = event.reminderMinutes;
    document.getElementById('eventColor').value = event.color;
    document.getElementById('deleteBtn').style.display = 'block';
    
    document.getElementById('eventModal').style.display = 'block';
}

function closeEventModal() {
    document.getElementById('eventModal').style.display = 'none';
    currentEventData = null;
}

// Event Form Submission
document.getElementById('eventForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const eventId = document.getElementById('eventId').value;
    const isUpdate = eventId && eventId.trim() !== '';
    
    // Get the exact datetime values without timezone conversion
    const startDateInput = document.getElementById('eventStartDate').value;
    const endDateInput = document.getElementById('eventEndDate').value;
    
    const eventData = {
        userEmail: currentUserEmail,
        title: document.getElementById('eventTitle').value,
        description: document.getElementById('eventDescription').value,
        startDate: startDateInput,
        endDate: endDateInput,
        category: document.getElementById('eventCategory').value,
        recurring: document.getElementById('eventRecurring').value,
        reminderMinutes: parseInt(document.getElementById('eventReminder').value),
        color: document.getElementById('eventColor').value
    };
    
    // Validate dates
    if (new Date(eventData.endDate) <= new Date(eventData.startDate)) {
        alert('End date must be after start date');
        return;
    }
    
    // Check for conflicts locally first
    const hasConflict = checkLocalConflicts(eventData);
    if (hasConflict && !eventData.forceCreate && !eventData.forceUpdate) {
        // Show conflict warning and get server suggestions
        try {
            let response;
            if (isUpdate && currentEventData && currentEventData._id) {
                response = await fetch(`/api/events/${currentEventData._id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(eventData)
                });
            } else {
                response = await fetch('/api/events', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(eventData)
                });
            }
            
            if (response.status === 409) {
                const conflictData = await response.json();
                showConflictModal(conflictData, eventData);
                return;
            }
        } catch (error) {
            console.error('Error checking conflicts:', error);
        }
        return;
    }
    
    try {
        let response;
        if (isUpdate && currentEventData && currentEventData._id) {
            // Update existing event
            response = await fetch(`/api/events/${currentEventData._id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(eventData)
            });
        } else {
            // Create new event
            response = await fetch('/api/events', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(eventData)
            });
        }
        
        if (response.status === 409) {
            // Handle conflict
            const conflictData = await response.json();
            showConflictModal(conflictData, eventData);
            return;
        }
        
        if (response.ok) {
            closeEventModal();
            loadUserEvents();
            scheduleReminder(eventData);
        } else {
            const error = await response.json();
            alert('Error: ' + error.message);
        }
    } catch (error) {
        console.error('Error saving event:', error);
        alert('Failed to save event');
    }
});

// Check for local conflicts before sending to server
function checkLocalConflicts(eventData) {
    const currentEventId = currentEventData ? currentEventData._id : null;
    
    return events.some(event => {
        // Skip checking against the current event being edited
        if (currentEventId && event._id === currentEventId) {
            return false;
        }
        
        const eventStart = new Date(event.startDate);
        const eventEnd = new Date(event.endDate);
        const newStart = new Date(eventData.startDate);
        const newEnd = new Date(eventData.endDate);
        
        // Check for time overlap
        return (newStart < eventEnd && newEnd > eventStart);
    });
}

// Conflict Modal Functions
function showConflictModal(conflictData, eventData) {
    currentEventData = eventData;
    
    const conflictList = document.getElementById('conflictList');
    conflictList.innerHTML = '';
    
    // Show conflict message
    const conflictMessage = document.createElement('div');
    conflictMessage.style.marginBottom = '16px';
    conflictMessage.style.padding = '12px';
    conflictMessage.style.background = 'rgba(245, 87, 108, 0.1)';
    conflictMessage.style.border = '1px solid rgba(245, 87, 108, 0.3)';
    conflictMessage.style.borderRadius = '8px';
    conflictMessage.style.color = 'var(--text-primary)';
    conflictMessage.innerHTML = `
        <strong>⚠️ Schedule Conflict Detected!</strong><br>
        Your event "<strong>${eventData.title}</strong>" from ${new Date(eventData.startDate).toLocaleString()} to ${new Date(eventData.endDate).toLocaleString()} conflicts with the following existing events:
    `;
    conflictList.appendChild(conflictMessage);
    
    conflictData.conflicts.forEach(conflict => {
        const conflictItem = document.createElement('div');
        conflictItem.className = 'conflict-item';
        conflictItem.innerHTML = `
            <div>
                <strong>${conflict.title}</strong><br>
                <small>📅 ${new Date(conflict.startDate).toLocaleString()} - ${new Date(conflict.endDate).toLocaleString()}</small><br>
                <small>📂 Category: ${conflict.category}</small>
            </div>
            <button onclick="rescheduleConflictingEvent('${conflict._id}')" class="cancel-btn" style="margin-left: 10px; padding: 4px 8px; font-size: 12px;">
                Reschedule This Event
            </button>
        `;
        conflictList.appendChild(conflictItem);
    });
    
    const suggestionList = document.getElementById('suggestionList');
    suggestionList.innerHTML = '';
    
    if (conflictData.suggestions && conflictData.suggestions.length > 0) {
        conflictData.suggestions.forEach((suggestion, index) => {
            const suggestionItem = document.createElement('div');
            suggestionItem.className = 'suggestion-item';
            suggestionItem.innerHTML = `
                <div>
                    <strong>Option ${index + 1}</strong><br>
                    ${new Date(suggestion.startDate).toLocaleString()} - ${new Date(suggestion.endDate).toLocaleString()}
                </div>
            `;
            suggestionItem.addEventListener('click', () => {
                // Update the form fields with the suggested times
                document.getElementById('eventStartDate').value = new Date(suggestion.startDate).toISOString().slice(0, 16);
                document.getElementById('eventEndDate').value = new Date(suggestion.endDate).toISOString().slice(0, 16);
                closeConflictModal();
                
                // Don't automatically change currentEventData - let user decide to save
            });
            suggestionList.appendChild(suggestionItem);
        });
    } else {
        suggestionList.innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 20px;">No alternative times available. Try a different date.</p>';
    }
    
    document.getElementById('conflictModal').style.display = 'block';
}

function closeConflictModal() {
    document.getElementById('conflictModal').style.display = 'none';
}

async function forceCreateEvent() {
    // Force create or update event despite conflicts
    try {
        const eventId = document.getElementById('eventId').value;
        const isUpdate = eventId && eventId.trim() !== '';
        
        const eventData = {
            userEmail: currentUserEmail,
            title: document.getElementById('eventTitle').value,
            description: document.getElementById('eventDescription').value,
            startDate: new Date(document.getElementById('eventStartDate').value),
            endDate: new Date(document.getElementById('eventEndDate').value),
            category: document.getElementById('eventCategory').value,
            recurring: document.getElementById('eventRecurring').value,
            reminderMinutes: parseInt(document.getElementById('eventReminder').value),
            color: document.getElementById('eventColor').value
        };
        
        let response;
        if (isUpdate && currentEventData && currentEventData._id) {
            response = await fetch(`/api/events/${currentEventData._id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...eventData,
                    forceUpdate: true
                })
            });
        } else {
            response = await fetch('/api/events', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...eventData,
                    forceCreate: true
                })
            });
        }
        
        if (response.ok) {
            closeConflictModal();
            closeEventModal();
            loadUserEvents();
        } else {
            const error = await response.json();
            alert('Error: ' + error.message);
        }
    } catch (error) {
        console.error('Error force creating/updating event:', error);
        alert('Failed to save event');
    }
}

// Delete Event
async function deleteCurrentEvent() {
    if (!currentEventData || !currentEventData._id) return;
    
    if (confirm('Are you sure you want to delete this event?')) {
        try {
            const response = await fetch(`/api/events/${currentEventData._id}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                closeEventModal();
                loadUserEvents();
            } else {
                alert('Failed to delete event');
            }
        } catch (error) {
            console.error('Error deleting event:', error);
            alert('Failed to delete event');
        }
    }
}

// Day Events Modal
function showDayEvents(date) {
    selectedDate = date;
    const dayEvents = getDayEvents(date);
    
    document.getElementById('dayEventsTitle').textContent = `Events for ${date.toLocaleDateString()}`;
    
    const dayEventsList = document.getElementById('dayEventsList');
    dayEventsList.innerHTML = '';
    
    if (dayEvents.length === 0) {
        dayEventsList.innerHTML = '<p>No events for this day</p>';
    } else {
        dayEvents.forEach(event => {
            const eventItem = document.createElement('div');
            eventItem.className = 'event-item';
            eventItem.innerHTML = `
                <div class="event-time">${new Date(event.startDate).toLocaleTimeString()} - ${new Date(event.endDate).toLocaleTimeString()}</div>
                <div class="event-title">${event.title}</div>
                <div class="event-description">${event.description || ''}</div>
                <div class="event-category">${event.category}</div>
            `;
            eventItem.addEventListener('click', () => {
                closeDayEventsModal();
                editEvent(event);
            });
            dayEventsList.appendChild(eventItem);
        });
    }
    
    document.getElementById('dayEventsModal').style.display = 'block';
}

function closeDayEventsModal() {
    document.getElementById('dayEventsModal').style.display = 'none';
}

function addEventForDay() {
    closeDayEventsModal();
    showAddEventModal(selectedDate);
}

// Filter Events
function filterEvents() {
    renderCalendar();
}

// Reminder System
function scheduleReminder(eventData) {
    const eventStart = new Date(eventData.startDate);
    const reminderTime = new Date(eventStart.getTime() - (eventData.reminderMinutes * 60000));
    const now = new Date();
    
    if (reminderTime > now) {
        const timeoutDuration = reminderTime.getTime() - now.getTime();
        
        if (timeoutDuration <= 2147483647) { // Max timeout value
            setTimeout(() => {
                showReminder(eventData);
            }, timeoutDuration);
        }
    }
}

function showReminder(eventData) {
    if (Notification.permission === 'granted') {
        new Notification(`Upcoming Event: ${eventData.title}`, {
            body: `Starting in ${eventData.reminderMinutes} minutes`,
            icon: '/favicon.ico'
        });
    } else {
        alert(`Reminder: ${eventData.title} starts in ${eventData.reminderMinutes} minutes`);
    }
}

// Request notification permission
if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
}

// Close modals when clicking outside
window.addEventListener('click', function(event) {
    const modals = ['emailModal', 'eventModal', 'conflictModal', 'dayEventsModal'];
    modals.forEach(modalId => {
        const modal = document.getElementById(modalId);
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});

// Quick time selection functions
function setQuickTime(type, hour) {
    const input = document.getElementById(type === 'start' ? 'eventStartDate' : 'eventEndDate');
    const currentValue = input.value;
    
    if (currentValue) {
        const date = new Date(currentValue);
        date.setHours(hour, 0, 0, 0);
        input.value = date.toISOString().slice(0, 16);
        
        // Only auto-update end time if it's currently empty or if end time is before start time
        if (type === 'start') {
            const endInput = document.getElementById('eventEndDate');
            const endValue = endInput.value;
            
            if (!endValue || new Date(endValue) <= date) {
                const endDate = new Date(date);
                endDate.setHours(endDate.getHours() + 1);
                endInput.value = endDate.toISOString().slice(0, 16);
            }
        }
    }
}

function setDuration(hours) {
    const startInput = document.getElementById('eventStartDate');
    const endInput = document.getElementById('eventEndDate');
    
    if (startInput.value) {
        const startDate = new Date(startInput.value);
        const endDate = new Date(startDate);
        endDate.setTime(endDate.getTime() + (hours * 60 * 60 * 1000));
        endInput.value = endDate.toISOString().slice(0, 16);
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        // Close any open modal
        const modals = ['eventModal', 'conflictModal', 'dayEventsModal'];
        modals.forEach(modalId => {
            const modal = document.getElementById(modalId);
            if (modal.style.display === 'block') {
                modal.style.display = 'none';
            }
        });
    }
    
    if (event.key === 'n' && (event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        showAddEventModal();
    }
});
// Analytics Functions
function toggleAnalytics() {
    analyticsVisible = !analyticsVisible;
    const panel = document.getElementById('analyticsPanel');
    const grid = document.querySelector('.content-grid');
    
    if (analyticsVisible) {
        panel.style.display = 'block';
        grid.classList.add('with-analytics');
        loadAnalytics();
    } else {
        panel.style.display = 'none';
        grid.classList.remove('with-analytics');
    }
}

async function loadAnalytics() {
    try {
        const response = await fetch(`/api/events/analytics/${encodeURIComponent(currentUserEmail)}`);
        if (response.ok) {
            const analytics = await response.json();
            renderAnalytics(analytics);
        }
    } catch (error) {
        console.error('Error loading analytics:', error);
    }
}

function renderAnalytics(analytics) {
    // Total Events
    document.getElementById('totalEvents').textContent = analytics.totalEvents;
    
    // Activity Chart
    renderActivityChart(analytics.activityData);
    
    // Category Chart
    renderCategoryChart(analytics.categoryData);
    
    // Time Chart
    renderTimeChart(analytics.timeSlotData);
}

function renderActivityChart(activityData) {
    const container = document.getElementById('activityChart');
    container.innerHTML = '';
    
    if (activityData.length === 0) {
        container.innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 20px;">No recent activity</p>';
        return;
    }
    
    const maxCount = Math.max(...activityData.map(d => d.count));
    
    activityData.slice(-7).forEach(data => {
        const bar = document.createElement('div');
        bar.className = 'chart-bar';
        bar.style.width = `${(data.count / maxCount) * 100}%`;
        bar.style.minWidth = '20px';
        bar.textContent = `${new Date(data.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}: ${data.count}`;
        container.appendChild(bar);
    });
}

function renderCategoryChart(categoryData) {
    const container = document.getElementById('categoryChart');
    container.innerHTML = '';
    
    Object.entries(categoryData).forEach(([category, hours]) => {
        if (hours > 0) {
            const item = document.createElement('div');
            item.className = 'category-item';
            item.innerHTML = `
                <div class="category-name">
                    <div class="category-dot ${category.toLowerCase()}"></div>
                    ${category}
                </div>
                <div class="category-hours">${hours.toFixed(1)}h</div>
            `;
            container.appendChild(item);
        }
    });
    
    if (container.children.length === 0) {
        container.innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 20px;">No category data</p>';
    }
}

function renderTimeChart(timeData) {
    const container = document.getElementById('timeChart');
    container.innerHTML = '';
    
    if (timeData.length === 0) {
        container.innerHTML = '<p style="color: var(--text-secondary); text-align: center; padding: 20px;">No time data</p>';
        return;
    }
    
    const maxCount = Math.max(...timeData.map(d => d.count));
    const topTimes = timeData.sort((a, b) => b.count - a.count).slice(0, 5);
    
    topTimes.forEach(data => {
        const bar = document.createElement('div');
        bar.className = 'chart-bar';
        bar.style.width = `${(data.count / maxCount) * 100}%`;
        bar.style.minWidth = '30px';
        bar.textContent = `${data.time}: ${data.count} events`;
        container.appendChild(bar);
    });
}

async function rescheduleConflictingEvent(eventId) {
    try {
        const conflictingEvent = events.find(e => e._id === eventId);
        if (conflictingEvent) {
            closeConflictModal();
            closeEventModal(); // Close the current event modal first
            setTimeout(() => {
                editEvent(conflictingEvent);
            }, 100); // Small delay to ensure modal is closed
        }
    } catch (error) {
        console.error('Error rescheduling conflicting event:', error);
    }
}
