
const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  userEmail: {
    type: String,
    required: true,
    index: true
  },
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    default: ''
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  category: {
    type: String,
    enum: ['Work', 'Personal', 'School'],
    default: 'Personal'
  },
  recurring: {
    type: String,
    enum: ['none', 'daily', 'weekly', 'monthly'],
    default: 'none'
  },
  reminderMinutes: {
    type: Number,
    default: 15
  },
  color: {
    type: String,
    default: '#00ffff'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Event', eventSchema);
