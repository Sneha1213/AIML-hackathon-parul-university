
const Event = require('../models/Event');

// Get all events for a user
const getUserEvents = async (req, res) => {
  try {
    const { email } = req.params;
    const events = await Event.find({ userEmail: email }).sort({ startDate: 1 });
    res.json(events);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Create a new event
const createEvent = async (req, res) => {
  try {
    const eventData = req.body;
    
    // Convert string dates to Date objects for storage
    const processedEventData = {
      ...eventData,
      startDate: new Date(eventData.startDate),
      endDate: new Date(eventData.endDate)
    };
    
    // Check for conflicts unless force create is specified
    if (!eventData.forceCreate) {
      const conflicts = await Event.find({
        userEmail: eventData.userEmail,
        $and: [
          {
            $or: [
              {
                $and: [
                  { startDate: { $lte: processedEventData.startDate } },
                  { endDate: { $gt: processedEventData.startDate } }
                ]
              },
              {
                $and: [
                  { startDate: { $lt: processedEventData.endDate } },
                  { endDate: { $gte: processedEventData.endDate } }
                ]
              },
              {
                $and: [
                  { startDate: { $gte: processedEventData.startDate } },
                  { endDate: { $lte: processedEventData.endDate } }
                ]
              }
            ]
          }
        ]
      });

      if (conflicts.length > 0) {
        return res.status(409).json({ 
          message: 'Schedule conflict detected! The following events overlap with your selected time.',
          conflicts: conflicts,
          suggestions: await generateAlternativeTimes(eventData.userEmail, eventData.startDate, eventData.endDate)
        });
      }
    }

    // Remove forceCreate from eventData before saving
    const { forceCreate, ...cleanEventData } = processedEventData;
    const event = new Event(cleanEventData);
    const savedEvent = await event.save();
    res.status(201).json(savedEvent);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Update an event
const updateEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const eventData = req.body;
    
    // Convert string dates to Date objects for storage
    const processedEventData = {
      ...eventData,
      startDate: new Date(eventData.startDate),
      endDate: new Date(eventData.endDate)
    };
    
    // Check for conflicts (excluding current event) unless force update
    if (!eventData.forceUpdate) {
      const conflicts = await Event.find({
        _id: { $ne: id },
        userEmail: eventData.userEmail,
        $and: [
          {
            $or: [
              {
                $and: [
                  { startDate: { $lte: processedEventData.startDate } },
                  { endDate: { $gt: processedEventData.startDate } }
                ]
              },
              {
                $and: [
                  { startDate: { $lt: processedEventData.endDate } },
                  { endDate: { $gte: processedEventData.endDate } }
                ]
              },
              {
                $and: [
                  { startDate: { $gte: processedEventData.startDate } },
                  { endDate: { $lte: processedEventData.endDate } }
                ]
              }
            ]
          }
        ]
      });

      if (conflicts.length > 0) {
        return res.status(409).json({ 
          message: 'Schedule conflict detected! The following events overlap with your selected time.',
          conflicts: conflicts,
          suggestions: await generateAlternativeTimes(eventData.userEmail, eventData.startDate, eventData.endDate)
        });
      }
    }

    // Remove forceUpdate from eventData before saving
    const { forceUpdate, ...cleanEventData } = processedEventData;
    const updatedEvent = await Event.findByIdAndUpdate(id, cleanEventData, { new: true });
    if (!updatedEvent) {
      return res.status(404).json({ message: 'Event not found' });
    }
    res.json(updatedEvent);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Delete an event
const deleteEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedEvent = await Event.findByIdAndDelete(id);
    if (!deletedEvent) {
      return res.status(404).json({ message: 'Event not found' });
    }
    res.json({ message: 'Event deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Generate alternative times for conflicts
const generateAlternativeTimes = async (userEmail, startDate, endDate) => {
  const duration = new Date(endDate) - new Date(startDate);
  const alternatives = [];
  
  // Get all user events to check for conflicts
  const userEvents = await Event.find({ userEmail });
  
  // Try different time slots
  const baseDate = new Date(startDate);
  for (let dayOffset = 0; dayOffset < 7; dayOffset++) {
    for (let hourOffset = 1; hourOffset <= 8; hourOffset++) {
      const newStart = new Date(baseDate);
      newStart.setDate(newStart.getDate() + dayOffset);
      newStart.setHours(newStart.getHours() + hourOffset);
      const newEnd = new Date(newStart.getTime() + duration);
      
      // Check if this time slot conflicts with existing events
      const hasConflict = userEvents.some(event => {
        const eventStart = new Date(event.startDate);
        const eventEnd = new Date(event.endDate);
        return newStart < eventEnd && newEnd > eventStart;
      });
      
      if (!hasConflict) {
        alternatives.push({
          startDate: newStart,
          endDate: newEnd
        });
        
        if (alternatives.length >= 5) break;
      }
    }
    if (alternatives.length >= 5) break;
  }
  
  return alternatives;
};

module.exports = {
  getUserEvents,
  createEvent,
  updateEvent,
  deleteEvent
};
// Get analytics data for a user
const getUserAnalytics = async (req, res) => {
  try {
    const { email } = req.params;
    const events = await Event.find({ userEmail: email });
    
    // Event activity over days (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const activityData = {};
    const categoryData = { Work: 0, Personal: 0, School: 0 };
    const timeSlotData = {};
    
    events.forEach(event => {
      const eventDate = new Date(event.startDate);
      const dateKey = eventDate.toISOString().split('T')[0];
      
      // Activity over days
      if (eventDate >= thirtyDaysAgo) {
        activityData[dateKey] = (activityData[dateKey] || 0) + 1;
      }
      
      // Category time tracking
      const duration = (new Date(event.endDate) - new Date(event.startDate)) / (1000 * 60 * 60); // hours
      categoryData[event.category] += duration;
      
      // Most used time slots
      const hour = eventDate.getHours();
      const timeSlot = `${hour}:00`;
      timeSlotData[timeSlot] = (timeSlotData[timeSlot] || 0) + 1;
    });
    
    // Convert to arrays for frontend
    const activityArray = Object.entries(activityData)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, count]) => ({ date, count }));
    
    const timeSlotArray = Object.entries(timeSlotData)
      .sort(([a], [b]) => parseInt(a) - parseInt(b))
      .map(([time, count]) => ({ time, count }));
    
    res.json({
      totalEvents: events.length,
      activityData: activityArray,
      categoryData,
      timeSlotData: timeSlotArray
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getUserEvents,
  createEvent,
  updateEvent,
  deleteEvent,
  getUserAnalytics
};
