
const express = require('express');
const router = express.Router();
const {
  getUserEvents,
  createEvent,
  updateEvent,
  deleteEvent,
  getUserAnalytics
} = require('../controllers/eventController');

// Get all events for a user
router.get('/user/:email', getUserEvents);

// Create a new event
router.post('/', createEvent);

// Update an event
router.put('/:id', updateEvent);

// Delete an event
router.delete('/:id', deleteEvent);

// Get analytics for a user
router.get('/analytics/:email', getUserAnalytics);

module.exports = router;
