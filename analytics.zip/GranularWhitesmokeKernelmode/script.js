
// User data
const users = [
    { name: "Riya Mehta", lastVisit: "2 hours ago", location: "Mumbai", category: "Medical", interest: "Cardiology" },
    { name: "Aarav Sharma", lastVisit: "5 hours ago", location: "Delhi", category: "Technical", interest: "AI/ML" },
    { name: "Priya Patel", lastVisit: "1 day ago", location: "Bangalore", category: "Non-Technical", interest: "Sales" },
    { name: "Rohan Gupta", lastVisit: "3 hours ago", location: "Chennai", category: "Medical", interest: "Neurology" },
    { name: "Ananya Singh", lastVisit: "6 hours ago", location: "Pune", category: "Technical", interest: "LangChain" },
    { name: "Vikram Reddy", lastVisit: "2 days ago", location: "Hyderabad", category: "Non-Technical", interest: "HR" },
    { name: "Kavya Nair", lastVisit: "4 hours ago", location: "Kochi", category: "Medical", interest: "Pediatrics" },
    { name: "Arjun Joshi", lastVisit: "1 hour ago", location: "Ahmedabad", category: "Technical", interest: "GPT-4o" },
    { name: "Sneha Agarwal", lastVisit: "8 hours ago", location: "Jaipur", category: "Non-Technical", interest: "Marketing" },
    { name: "Karthik Iyer", lastVisit: "12 hours ago", location: "Bangalore", category: "Medical", interest: "Radiology" },
    { name: "Divya Kulkarni", lastVisit: "3 days ago", location: "Mumbai", category: "Technical", interest: "Pinecone" },
    { name: "Rajesh Kumar", lastVisit: "1 day ago", location: "Delhi", category: "Non-Technical", interest: "Operations" },
    { name: "Meera Chauhan", lastVisit: "6 hours ago", location: "Surat", category: "Medical", interest: "General Practice" },
    { name: "Nikhil Verma", lastVisit: "2 hours ago", location: "Lucknow", category: "Technical", interest: "Firebase" },
    { name: "Pooja Bansal", lastVisit: "5 days ago", location: "Chandigarh", category: "Non-Technical", interest: "Finance" }
];

let currentTheme = 'dark';
let filteredUsers = [...users];

// Initialize the dashboard
document.addEventListener('DOMContentLoaded', function() {
    initializeTabs();
    initializeTheme();
    initializeSearch();
    renderUsers();
    initializeCharts();
});

// Tab functionality
function initializeTabs() {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetTab = btn.getAttribute('data-tab');
            
            // Remove active class from all tabs and contents
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            btn.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
            
            // Reinitialize charts for the active tab
            setTimeout(() => initializeCharts(), 100);
        });
    });
}

// Theme toggle
function initializeTheme() {
    const themeToggle = document.getElementById('themeToggle');
    
    themeToggle.addEventListener('click', () => {
        currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.body.setAttribute('data-theme', currentTheme);
        themeToggle.textContent = currentTheme === 'dark' ? '🌙' : '☀️';
        
        // Reinitialize charts with new theme
        setTimeout(() => initializeCharts(), 100);
    });
}

// Search functionality
function initializeSearch() {
    const searchInput = document.getElementById('searchInput');
    
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        filteredUsers = users.filter(user => 
            user.name.toLowerCase().includes(query) ||
            user.category.toLowerCase().includes(query) ||
            user.interest.toLowerCase().includes(query)
        );
        renderUsers();
    });
}

// Render users list
function renderUsers() {
    const usersList = document.getElementById('usersList');
    usersList.innerHTML = '';
    
    filteredUsers.forEach(user => {
        const userElement = document.createElement('div');
        userElement.className = 'user-item';
        userElement.innerHTML = `
            <div class="user-name">${user.name}</div>
            <div class="user-details">
                Last visit: ${user.lastVisit}<br>
                Location: ${user.location}<br>
                Interest: ${user.interest}
            </div>
            <div class="user-category">${user.category}</div>
        `;
        usersList.appendChild(userElement);
    });
}

// Chart configuration
function getChartColors() {
    return currentTheme === 'dark' 
        ? {
            primary: '#6366f1',
            secondary: '#8b5cf6',
            accent: '#a855f7',
            text: '#e8e8f0',
            grid: 'rgba(99, 102, 241, 0.1)'
          }
        : {
            primary: '#6366f1',
            secondary: '#8b5cf6',
            accent: '#a855f7',
            text: '#1e293b',
            grid: 'rgba(99, 102, 241, 0.1)'
          };
}

// Initialize all charts
function initializeCharts() {
    // Destroy existing charts
    Chart.helpers.each(Chart.instances, function(instance) {
        instance.destroy();
    });
    
    const colors = getChartColors();
    
    // Medical Pie Chart
    const medicalCtx = document.getElementById('medicalPieChart');
    if (medicalCtx) {
        new Chart(medicalCtx, {
            type: 'pie',
            data: {
                labels: ['Cardiology', 'Neurology', 'Orthopedics', 'Pediatrics', 'Radiology', 'General Practice'],
                datasets: [{
                    data: [30, 20, 15, 10, 10, 15],
                    backgroundColor: [
                        colors.primary,
                        colors.secondary,
                        colors.accent,
                        '#f59e0b',
                        '#10b981',
                        '#ef4444'
                    ],
                    borderWidth: 2,
                    borderColor: currentTheme === 'dark' ? '#1a1a2e' : '#ffffff'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: {
                            color: colors.text
                        }
                    }
                }
            }
        });
    }

    // Preferences Chart
    const preferencesCtx = document.getElementById('preferencesChart');
    if (preferencesCtx) {
        new Chart(preferencesCtx, {
            type: 'doughnut',
            data: {
                labels: ['Hybrid CME', 'Online-only', 'In-person'],
                datasets: [{
                    data: [70, 20, 10],
                    backgroundColor: [colors.primary, colors.secondary, colors.accent],
                    borderWidth: 2,
                    borderColor: currentTheme === 'dark' ? '#1a1a2e' : '#ffffff'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: {
                            color: colors.text
                        }
                    }
                }
            }
        });
    }

    // Technical Bar Chart
    const technicalCtx = document.getElementById('technicalBarChart');
    if (technicalCtx) {
        new Chart(technicalCtx, {
            type: 'bar',
            data: {
                labels: ['LangChain', 'Pinecone', 'GPT-4o', 'Firebase', 'Others'],
                datasets: [{
                    label: 'Usage %',
                    data: [35, 25, 20, 15, 5],
                    backgroundColor: colors.primary,
                    borderColor: colors.secondary,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: colors.text
                        },
                        grid: {
                            color: colors.grid
                        }
                    },
                    x: {
                        ticks: {
                            color: colors.text
                        },
                        grid: {
                            color: colors.grid
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: colors.text
                        }
                    }
                }
            }
        });
    }

    // Engagement Radar Chart
    const engagementCtx = document.getElementById('engagementRadarChart');
    if (engagementCtx) {
        new Chart(engagementCtx, {
            type: 'radar',
            data: {
                labels: ['Sales', 'HR', 'Marketing', 'Operations', 'Finance'],
                datasets: [{
                    label: 'Engagement %',
                    data: [75, 60, 50, 40, 35],
                    backgroundColor: 'rgba(99, 102, 241, 0.2)',
                    borderColor: colors.primary,
                    borderWidth: 2,
                    pointBackgroundColor: colors.secondary,
                    pointBorderColor: colors.primary,
                    pointHoverBackgroundColor: colors.accent,
                    pointHoverBorderColor: colors.secondary
                }]
            },
            options: {
                responsive: true,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            color: colors.text
                        },
                        grid: {
                            color: colors.grid
                        },
                        angleLines: {
                            color: colors.grid
                        },
                        pointLabels: {
                            color: colors.text
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: colors.text
                        }
                    }
                }
            }
        });
    }
}

// Mobile swipe functionality for tabs
let startX = 0;
let endX = 0;

document.addEventListener('touchstart', e => {
    startX = e.changedTouches[0].screenX;
});

document.addEventListener('touchend', e => {
    endX = e.changedTouches[0].screenX;
    handleSwipe();
});

function handleSwipe() {
    const threshold = 50;
    const diff = startX - endX;
    
    if (Math.abs(diff) > threshold) {
        const activeTab = document.querySelector('.tab-btn.active');
        const tabs = Array.from(document.querySelectorAll('.tab-btn'));
        const currentIndex = tabs.indexOf(activeTab);
        
        if (diff > 0 && currentIndex < tabs.length - 1) {
            // Swipe left - next tab
            tabs[currentIndex + 1].click();
        } else if (diff < 0 && currentIndex > 0) {
            // Swipe right - previous tab
            tabs[currentIndex - 1].click();
        }
    }
}

// Smooth animations on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe all cards for animation
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.chart-card, .preferences-card, .trends-card');
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
});
