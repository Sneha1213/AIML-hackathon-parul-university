import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertRedemptionSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get user data with refreshed coins
  app.get("/api/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      let user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Refresh coins on each request (simulate coin regeneration)
      const refreshedCoins = Math.floor(Math.random() * 3000) + 1500; // Random coins between 1500-4500
      user = await storage.updateUserCoins(userId, refreshedCoins);
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all courses
  app.get("/api/courses", async (req, res) => {
    try {
      const courses = await storage.getCourses();
      res.json(courses);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all products
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all offers
  app.get("/api/offers", async (req, res) => {
    try {
      const offers = await storage.getOffers();
      res.json(offers);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Redeem course
  app.post("/api/redeem/course", async (req, res) => {
    try {
      const { userId, courseId } = req.body;
      
      const user = await storage.getUser(userId);
      const course = await storage.getCourse(courseId);
      
      if (!user || !course) {
        return res.status(404).json({ message: "User or course not found" });
      }
      
      if (user.coins < course.coinsRequired) {
        return res.status(400).json({ message: "Insufficient coins" });
      }
      
      // Update user coins
      const updatedUser = await storage.updateUserCoins(userId, user.coins - course.coinsRequired);
      
      // Create redemption record
      await storage.createRedemption({
        userId,
        itemType: "course",
        itemId: courseId,
        coinsUsed: course.coinsRequired
      });
      
      res.json({ 
        message: "Course redeemed successfully",
        user: updatedUser,
        course
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Redeem product
  app.post("/api/redeem/product", async (req, res) => {
    try {
      const { userId, productId } = req.body;
      
      const user = await storage.getUser(userId);
      const product = await storage.getProduct(productId);
      
      if (!user || !product) {
        return res.status(404).json({ message: "User or product not found" });
      }
      
      if (user.coins < product.coinsRequired) {
        return res.status(400).json({ message: "Insufficient coins" });
      }
      
      // Update user coins
      const updatedUser = await storage.updateUserCoins(userId, user.coins - product.coinsRequired);
      
      // Create redemption record
      await storage.createRedemption({
        userId,
        itemType: "product",
        itemId: productId,
        coinsUsed: product.coinsRequired
      });
      
      res.json({ 
        message: "Product redeemed successfully",
        user: updatedUser,
        product
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Redeem offer
  app.post("/api/redeem/offer", async (req, res) => {
    try {
      const { userId, offerId } = req.body;
      
      const user = await storage.getUser(userId);
      const offer = await storage.getOffer(offerId);
      
      if (!user || !offer) {
        return res.status(404).json({ message: "User or offer not found" });
      }
      
      if (user.coins < offer.coinsRequired) {
        return res.status(400).json({ message: "Insufficient coins" });
      }
      
      // Update user coins
      const updatedUser = await storage.updateUserCoins(userId, user.coins - offer.coinsRequired);
      
      // Create redemption record
      await storage.createRedemption({
        userId,
        itemType: "offer",
        itemId: offerId,
        coinsUsed: offer.coinsRequired
      });
      
      res.json({ 
        message: "Offer redeemed successfully",
        user: updatedUser,
        offer
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
