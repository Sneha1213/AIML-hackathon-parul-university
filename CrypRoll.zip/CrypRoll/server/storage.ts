import { 
  users, courses, products, offers, redemptions,
  type User, type Course, type Product, type Offer, type Redemption,
  type InsertUser, type InsertCourse, type InsertProduct, type InsertOffer, type InsertRedemption
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByName(name: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserCoins(id: number, coins: number): Promise<User | undefined>;

  // Course operations
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;

  // Product operations
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Offer operations
  getOffers(): Promise<Offer[]>;
  getOffer(id: number): Promise<Offer | undefined>;
  createOffer(offer: InsertOffer): Promise<Offer>;

  // Redemption operations
  createRedemption(redemption: InsertRedemption): Promise<Redemption>;
  getUserRedemptions(userId: number): Promise<Redemption[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private courses: Map<number, Course>;
  private products: Map<number, Product>;
  private offers: Map<number, Offer>;
  private redemptions: Map<number, Redemption>;
  private currentUserId: number;
  private currentCourseId: number;
  private currentProductId: number;
  private currentOfferId: number;
  private currentRedemptionId: number;

  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.products = new Map();
    this.offers = new Map();
    this.redemptions = new Map();
    this.currentUserId = 1;
    this.currentCourseId = 1;
    this.currentProductId = 1;
    this.currentOfferId = 1;
    this.currentRedemptionId = 1;

    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Create default user with auto-renewing coins
    const defaultUser: User = {
      id: this.currentUserId++,
      name: "Sneha Satarke",
      coins: Math.floor(Math.random() * 3000) + 1500, // Random coins between 1500-4500
      avatar: null
    };
    this.users.set(defaultUser.id, defaultUser);

    // Initialize courses
    const coursesData = [
      {
        id: this.currentCourseId++,
        title: "Advanced Web Development",
        originalPrice: 2000,
        discount: 30,
        coinsRequired: 500,
        image: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      },
      {
        id: this.currentCourseId++,
        title: "AI & Machine Learning",
        originalPrice: 2500,
        discount: 25,
        coinsRequired: 600,
        image: "https://images.unsplash.com/photo-1507146426996-ef05306b995a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      },
      {
        id: this.currentCourseId++,
        title: "Data Science Mastery",
        originalPrice: 3000,
        discount: 35,
        coinsRequired: 750,
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      }
    ];
    coursesData.forEach(course => this.courses.set(course.id, course));

    // Initialize products
    const productsData = [
      {
        id: this.currentProductId++,
        name: "Microsoft Surface Hoodie",
        brand: "Microsoft",
        coinsRequired: 1500,
        image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      },
      {
        id: this.currentProductId++,
        name: "Google Pixel Backpack",
        brand: "Google",
        coinsRequired: 1200,
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      },
      {
        id: this.currentProductId++,
        name: "Apple MacBook Sleeve",
        brand: "Apple",
        coinsRequired: 2000,
        image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      },
      {
        id: this.currentProductId++,
        name: "Amazon Echo Dot",
        brand: "Amazon",
        coinsRequired: 800,
        image: "https://images.unsplash.com/photo-1543512214-318c7553f230?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      }
    ];
    productsData.forEach(product => this.products.set(product.id, product));

    // Initialize offers
    const offersData = [
      {
        id: this.currentOfferId++,
        platform: "Nykaa",
        productName: "Premium Beauty Kit",
        coinsRequired: 250,
        discount: 15,
        code: "NYK15-OFF",
        image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      },
      {
        id: this.currentOfferId++,
        platform: "Flipkart",
        productName: "Electronics Bundle",
        coinsRequired: 300,
        discount: 20,
        code: "FLIP20-SAVE",
        image: "https://images.unsplash.com/photo-1550009158-9ebf69173e03?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      },
      {
        id: this.currentOfferId++,
        platform: "Lenskart",
        productName: "Designer Eyewear",
        coinsRequired: 200,
        discount: 25,
        code: "LENS25-NEW",
        image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      },
      {
        id: this.currentOfferId++,
        platform: "Amazon",
        productName: "Tech Accessories",
        coinsRequired: 350,
        discount: 18,
        code: "AMZ18-TECH",
        image: "https://images.unsplash.com/photo-1468495244123-6c6c332eeece?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      }
    ];
    offersData.forEach(offer => this.offers.set(offer.id, offer));
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByName(name: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.name === name);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      coins: insertUser.coins || 0,
      avatar: insertUser.avatar || null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserCoins(id: number, coins: number): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, coins };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = this.currentCourseId++;
    const course: Course = { 
      ...insertCourse, 
      id,
      image: insertCourse.image || null
    };
    this.courses.set(id, course);
    return course;
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = { 
      ...insertProduct, 
      id,
      image: insertProduct.image || null
    };
    this.products.set(id, product);
    return product;
  }

  async getOffers(): Promise<Offer[]> {
    return Array.from(this.offers.values());
  }

  async getOffer(id: number): Promise<Offer | undefined> {
    return this.offers.get(id);
  }

  async createOffer(insertOffer: InsertOffer): Promise<Offer> {
    const id = this.currentOfferId++;
    const offer: Offer = { 
      ...insertOffer, 
      id,
      image: insertOffer.image || null
    };
    this.offers.set(id, offer);
    return offer;
  }

  async createRedemption(insertRedemption: InsertRedemption): Promise<Redemption> {
    const id = this.currentRedemptionId++;
    const redemption: Redemption = { 
      ...insertRedemption, 
      id,
      redeemedAt: new Date()
    };
    this.redemptions.set(id, redemption);
    return redemption;
  }

  async getUserRedemptions(userId: number): Promise<Redemption[]> {
    return Array.from(this.redemptions.values()).filter(r => r.userId === userId);
  }
}

export const storage = new MemStorage();
