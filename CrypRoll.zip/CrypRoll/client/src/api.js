class API {
  constructor(baseURL = '') {
    this.baseURL = baseURL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    if (config.body && typeof config.body === 'object') {
      config.body = JSON.stringify(config.body);
    }

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: response.statusText }));
        throw new Error(errorData.message || `HTTP ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error(`API request failed: ${error.message}`);
      throw error;
    }
  }

  async get(endpoint) {
    return this.request(endpoint, { method: 'GET' });
  }

  async post(endpoint, data) {
    return this.request(endpoint, {
      method: 'POST',
      body: data,
    });
  }

  async put(endpoint, data) {
    return this.request(endpoint, {
      method: 'PUT',
      body: data,
    });
  }

  async delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  }

  // User API methods
  async getUser(userId) {
    return this.get(`/api/user/${userId}`);
  }

  // Course API methods
  async getCourses() {
    return this.get('/api/courses');
  }

  async redeemCourse(userId, courseId) {
    return this.post('/api/redeem/course', { userId, courseId });
  }

  // Product API methods
  async getProducts() {
    return this.get('/api/products');
  }

  async redeemProduct(userId, productId) {
    return this.post('/api/redeem/product', { userId, productId });
  }

  // Offer API methods
  async getOffers() {
    return this.get('/api/offers');
  }

  async redeemOffer(userId, offerId) {
    return this.post('/api/redeem/offer', { userId, offerId });
  }
}

export default new API();
