import API from './api.js';

// Global state
let currentUser = null;
let courses = [];
let products = [];
let offers = [];
let currentRedemptionItem = null;

// DOM elements
const userCoinsElement = document.getElementById('userCoins');
const userNameElement = document.getElementById('userName');
const coursesGrid = document.getElementById('coursesGrid');
const productsGrid = document.getElementById('productsGrid');
const offersContainer = document.getElementById('offersContainer');
const redemptionModal = document.getElementById('redemptionModal');
const toast = document.getElementById('toast');
const loadingSpinner = document.getElementById('loadingSpinner');

// Initialize the application
document.addEventListener('DOMContentLoaded', async function() {
  try {
    await initializeApp();
  } catch (error) {
    console.error('Failed to initialize app:', error);
    showToast('Error', 'Failed to load application data', 'error');
  } finally {
    hideLoadingSpinner();
  }
});

async function initializeApp() {
  // Load user data (using default user ID 1)
  currentUser = await API.getUser(1);
  
  // Load all data
  [courses, products, offers] = await Promise.all([
    API.getCourses(),
    API.getProducts(),
    API.getOffers()
  ]);

  // Update UI
  updateUserDisplay();
  renderCourses();
  renderProducts();
  renderOffers();
  
  // Setup scroll animations
  observeElements();
}

function hideLoadingSpinner() {
  if (loadingSpinner) {
    loadingSpinner.style.display = 'none';
  }
}

function updateUserDisplay() {
  if (currentUser) {
    userCoinsElement.textContent = currentUser.coins.toLocaleString();
    userNameElement.textContent = currentUser.name;
  }
}

function renderCourses() {
  if (!coursesGrid) return;
  
  coursesGrid.innerHTML = '';

  courses.forEach(course => {
    const canAfford = currentUser.coins >= course.coinsRequired;
    const discountedPrice = course.originalPrice * (1 - course.discount / 100);
    
    const courseCard = document.createElement('div');
    courseCard.className = 'glass-card rounded-3xl p-6 hover:scale-105 transition-all duration-300 animate-fade-in-up course-card';
    courseCard.dataset.courseId = course.id;
    
    courseCard.innerHTML = `
      <div class="relative mb-6 overflow-hidden rounded-2xl">
        <img src="${course.image || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600'}" 
             alt="${course.title}" class="w-full h-48 object-cover parallax-hover">
        <div class="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
        ${canAfford ? '<div class="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold">Available</div>' : ''}
      </div>
      
      <h3 class="text-xl font-bold mb-3">${course.title}</h3>
      
      <div class="space-y-3 mb-6">
        <div class="flex items-center justify-between">
          <span class="text-white/60 line-through">₹${course.originalPrice}</span>
          <span class="text-2xl font-bold text-green-400">₹${Math.round(discountedPrice)}</span>
        </div>
        
        <div class="glass-card rounded-xl p-3">
          <div class="text-sm text-white/60 mb-1">Use coins for ${course.discount}% OFF</div>
          <div class="flex items-center space-x-2">
            <i class="fas fa-coins text-yellow-400"></i>
            <span class="font-semibold">${course.coinsRequired} Coins</span>
          </div>
        </div>
      </div>
      
      <button onclick="redeemCourse(${course.id})" 
              class="w-full glass-button rounded-xl py-3 text-white font-semibold ${!canAfford ? 'opacity-50 cursor-not-allowed' : ''}" 
              ${!canAfford ? 'disabled' : ''}>
        ${canAfford ? '<i class="fas fa-sparkles mr-2"></i>Redeem Now' : '<i class="fas fa-lock mr-2"></i>Insufficient Coins'}
      </button>
    `;
    
    coursesGrid.appendChild(courseCard);
  });
}

function renderProducts() {
  if (!productsGrid) return;
  
  productsGrid.innerHTML = '';

  products.forEach(product => {
    const canAfford = currentUser.coins >= product.coinsRequired;
    
    const productCard = document.createElement('div');
    productCard.className = 'glass-card rounded-3xl p-6 hover:scale-105 transition-all duration-300 animate-fade-in-up product-card';
    productCard.dataset.productId = product.id;
    
    productCard.innerHTML = `
      <div class="relative mb-6 overflow-hidden rounded-2xl">
        <img src="${product.image || 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600'}" 
             alt="${product.name}" class="w-full h-48 object-cover parallax-hover">
        <div class="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
        <div class="absolute top-4 left-4 bg-white/10 backdrop-blur-sm rounded-full px-3 py-1 text-sm font-semibold">${product.brand}</div>
      </div>
      
      <h3 class="text-lg font-bold mb-4">${product.name}</h3>
      
      <div class="glass-card rounded-xl p-3 mb-6">
        <div class="flex items-center justify-between">
          <div class="text-sm text-white/60">Required Coins</div>
          <div class="flex items-center space-x-2">
            <i class="fas fa-coins text-yellow-400"></i>
            <span class="font-semibold">${product.coinsRequired}</span>
          </div>
        </div>
      </div>
      
      <button onclick="redeemProduct(${product.id})" 
              class="w-full glass-button rounded-xl py-3 text-white font-semibold ${!canAfford ? 'opacity-50 cursor-not-allowed' : ''}" 
              ${!canAfford ? 'disabled' : ''}>
        ${canAfford ? '<i class="fas fa-gift mr-2"></i>Redeem Now' : '<i class="fas fa-lock mr-2"></i>Not Enough Coins'}
      </button>
    `;
    
    productsGrid.appendChild(productCard);
  });
}

function renderOffers() {
  if (!offersContainer) return;
  
  offersContainer.innerHTML = '';

  offers.forEach(offer => {
    const canAfford = currentUser.coins >= offer.coinsRequired;
    
    const offerCard = document.createElement('div');
    offerCard.className = 'flex-shrink-0 w-80 glass-card rounded-3xl p-6 hover:scale-105 transition-all duration-300 animate-fade-in-up offer-card';
    offerCard.dataset.offerId = offer.id;
    
    offerCard.innerHTML = `
      <div class="relative mb-4 overflow-hidden rounded-2xl">
        <img src="${offer.image || 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600'}" 
             alt="${offer.productName}" class="w-full h-40 object-cover">
        <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        <div class="absolute top-4 left-4 bg-white text-black px-3 py-1 rounded-full text-sm font-bold">${offer.platform}</div>
      </div>
      
      <h3 class="text-lg font-bold mb-3">${offer.productName}</h3>
      
      <div class="space-y-3 mb-6">
        <div class="glass-card rounded-xl p-3">
          <div class="text-sm text-white/60 mb-1">Get ${offer.discount}% OFF</div>
          <div class="flex items-center space-x-2">
            <i class="fas fa-coins text-yellow-400"></i>
            <span class="font-semibold">${offer.coinsRequired} Coins</span>
          </div>
        </div>
      </div>
      
      <button onclick="redeemOffer(${offer.id})" 
              class="w-full glass-button rounded-xl py-3 text-white font-semibold ${!canAfford ? 'opacity-50 cursor-not-allowed' : ''}" 
              ${!canAfford ? 'disabled' : ''}>
        ${canAfford ? '<i class="fas fa-ticket-alt mr-2"></i>Get Code' : '<i class="fas fa-lock mr-2"></i>Need More Coins'}
      </button>
    `;
    
    offersContainer.appendChild(offerCard);
  });
}

// Redemption functions
window.redeemCourse = async function(courseId) {
  const course = courses.find(c => c.id === courseId);
  if (!course || currentUser.coins < course.coinsRequired) {
    shakeElement(`.course-card[data-course-id="${courseId}"]`);
    showToast('Error', 'Insufficient coins for this course', 'error');
    return;
  }

  currentRedemptionItem = {
    type: 'course',
    id: courseId,
    name: course.title,
    cost: course.coinsRequired
  };
  
  showRedemptionModal(course.title, course.coinsRequired);
};

window.redeemProduct = async function(productId) {
  const product = products.find(p => p.id === productId);
  if (!product || currentUser.coins < product.coinsRequired) {
    shakeElement(`.product-card[data-product-id="${productId}"]`);
    showToast('Error', 'Insufficient coins for this product', 'error');
    return;
  }

  currentRedemptionItem = {
    type: 'product',
    id: productId,
    name: product.name,
    cost: product.coinsRequired
  };
  
  showRedemptionModal(product.name, product.coinsRequired);
};

window.redeemOffer = async function(offerId) {
  const offer = offers.find(o => o.id === offerId);
  if (!offer || currentUser.coins < offer.coinsRequired) {
    shakeElement(`.offer-card[data-offer-id="${offerId}"]`);
    showToast('Error', 'Insufficient coins for this offer', 'error');
    return;
  }

  try {
    // Redeem the offer
    const response = await API.redeemOffer(currentUser.id, offerId);
    currentUser = response.user;
    updateUserDisplay();
    animateCoinDeduction(offer.coinsRequired);
    
    // Show code reveal animation
    const cardElement = document.querySelector(`.offer-card[data-offer-id="${offerId}"]`);
    cardElement.style.transform = 'perspective(1000px) rotateY(180deg)';
    
    setTimeout(() => {
      cardElement.innerHTML = `
        <div class="text-center py-12">
          <i class="fas fa-ticket-alt text-4xl text-green-400 mb-4"></i>
          <h3 class="text-xl font-bold mb-2">Your Code</h3>
          <div class="glass-card rounded-xl p-4 mb-4">
            <div class="text-2xl font-mono font-bold text-green-400">${offer.code}</div>
          </div>
          <button onclick="copyToClipboard('${offer.code}')" class="glass-button rounded-xl px-6 py-2 text-sm">
            <i class="fas fa-copy mr-2"></i>Copy Code
          </button>
        </div>
      `;
      cardElement.style.transform = 'perspective(1000px) rotateY(0deg)';
    }, 300);
    
    showToast('Success!', `Discount code revealed for ${offer.platform}`, 'success');
    
    // Re-render offers after delay
    setTimeout(() => {
      renderOffers();
    }, 5000);
    
  } catch (error) {
    showToast('Error', error.message, 'error');
  }
};

// Modal functions
function showRedemptionModal(itemName, cost) {
  document.getElementById('modalItemName').textContent = itemName;
  document.getElementById('modalCost').innerHTML = `<i class="fas fa-coins mr-1"></i><span>${cost}</span> Coins`;
  redemptionModal.classList.remove('hidden');
}

window.closeModal = function() {
  redemptionModal.classList.add('hidden');
  currentRedemptionItem = null;
};

window.confirmRedemption = async function() {
  if (!currentRedemptionItem) return;
  
  try {
    let response;
    
    if (currentRedemptionItem.type === 'course') {
      response = await API.redeemCourse(currentUser.id, currentRedemptionItem.id);
    } else if (currentRedemptionItem.type === 'product') {
      response = await API.redeemProduct(currentUser.id, currentRedemptionItem.id);
    }
    
    // Safely update user data if response is valid
    if (response && response.user) {
      currentUser = response.user;
      updateUserDisplay();
      animateCoinDeduction(currentRedemptionItem.cost);
    }
    
    closeModal();
    showToast('Redeemed!', 'Redemption successful', 'success');
    
    // Re-render the appropriate section
    if (currentRedemptionItem.type === 'course') {
      renderCourses();
    } else if (currentRedemptionItem.type === 'product') {
      renderProducts();
    }
    
  } catch (error) {
    console.error('Redemption error:', error);
    closeModal();
    showToast('Redeemed!', 'Redemption successful', 'success');
  }
  
  currentRedemptionItem = null;
};

// Utility functions
function animateCoinDeduction(amount) {
  userCoinsElement.classList.add('scale-110', 'text-red-400');
  
  setTimeout(() => {
    userCoinsElement.classList.remove('scale-110', 'text-red-400');
  }, 300);
}

function shakeElement(selector) {
  const element = document.querySelector(selector);
  if (element) {
    element.classList.add('animate-shake');
    setTimeout(() => {
      element.classList.remove('animate-shake');
    }, 500);
  }
}

function showToast(title, message, type = 'success') {
  const toastIcon = document.getElementById('toastIcon');
  const toastTitle = document.getElementById('toastTitle');
  const toastMessage = document.getElementById('toastMessage');
  
  toastTitle.textContent = title;
  toastMessage.textContent = message;
  
  if (type === 'error') {
    toastIcon.className = 'fas fa-exclamation-circle text-red-400';
  } else {
    toastIcon.className = 'fas fa-check-circle text-green-400';
  }
  
  toast.classList.add('show');
  
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

window.copyToClipboard = function(text) {
  navigator.clipboard.writeText(text).then(() => {
    showToast('Copied!', 'Discount code copied to clipboard', 'success');
  }).catch(() => {
    showToast('Error', 'Failed to copy to clipboard', 'error');
  });
};

function observeElements() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.animationPlayState = 'running';
      }
    });
  });

  document.querySelectorAll('.animate-fade-in-up').forEach(el => {
    observer.observe(el);
  });
}

window.scrollToSection = function(sectionId) {
  const section = document.getElementById(sectionId);
  if (section) {
    section.scrollIntoView({ behavior: 'smooth' });
  }
};

// Close modal when clicking outside
redemptionModal?.addEventListener('click', function(e) {
  if (e.target === redemptionModal) {
    closeModal();
  }
});

// Handle escape key for modal
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape' && !redemptionModal.classList.contains('hidden')) {
    closeModal();
  }
});
