import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  coins: integer("coins").notNull().default(0),
  avatar: text("avatar"),
});

export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  originalPrice: integer("original_price").notNull(),
  discount: integer("discount").notNull(),
  coinsRequired: integer("coins_required").notNull(),
  image: text("image"),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  brand: text("brand").notNull(),
  coinsRequired: integer("coins_required").notNull(),
  image: text("image"),
});

export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  platform: text("platform").notNull(),
  productName: text("product_name").notNull(),
  coinsRequired: integer("coins_required").notNull(),
  discount: integer("discount").notNull(),
  code: text("code").notNull(),
  image: text("image"),
});

export const redemptions = pgTable("redemptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  itemType: text("item_type").notNull(), // 'course', 'product', 'offer'
  itemId: integer("item_id").notNull(),
  coinsUsed: integer("coins_used").notNull(),
  redeemedAt: timestamp("redeemed_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertCourseSchema = createInsertSchema(courses).omit({ id: true });
export const insertProductSchema = createInsertSchema(products).omit({ id: true });
export const insertOfferSchema = createInsertSchema(offers).omit({ id: true });
export const insertRedemptionSchema = createInsertSchema(redemptions).omit({ id: true, redeemedAt: true });

export type User = typeof users.$inferSelect;
export type Course = typeof courses.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Offer = typeof offers.$inferSelect;
export type Redemption = typeof redemptions.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type InsertOffer = z.infer<typeof insertOfferSchema>;
export type InsertRedemption = z.infer<typeof insertRedemptionSchema>;
