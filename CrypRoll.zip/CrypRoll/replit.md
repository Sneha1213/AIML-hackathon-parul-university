# RewardHub - Premium Rewards System

## Overview

RewardHub is a modern web application that enables users to redeem coins for premium courses, physical products, and discount offers from partner platforms. The application features a sophisticated coin-based reward system with an immersive dark-themed UI, glassmorphism design elements, and smooth animations.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom glassmorphism effects and gradient designs
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js REST API
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Drizzle Kit for migrations and schema management

### Database Design
The application uses a relational database with the following core entities:
- **Users**: Store user profiles, coins balance, and avatars
- **Courses**: Educational content with pricing and discount information
- **Products**: Physical branded merchandise with coin requirements
- **Offers**: Partner platform discount codes and promotions
- **Redemptions**: Transaction history tracking all user redemptions

## Key Components

### Reward System
- **Coin Economy**: Users accumulate coins to redeem rewards
- **Multi-Category Rewards**: Courses, physical products, and discount offers
- **Real-time Balance**: Live coin balance updates after redemptions
- **Transaction History**: Complete audit trail of all redemptions

### User Interface
- **Immersive Design**: Dark theme with electric purple/cyan/pink gradients
- **Glassmorphism**: Frosted glass effects on cards and navigation elements
- **3D Visual Effects**: Floating shapes, parallax animations, and depth illusions
- **Responsive Layout**: Mobile-first design with adaptive grid systems
- **Interactive Animations**: Hover effects, loading states, and success notifications

### Authentication & User Management
- User profiles with avatar support
- Coin balance tracking and updates
- Redemption eligibility validation
- Transaction success/failure handling

## Data Flow

1. **User Authentication**: Users access their profile and coin balance
2. **Content Loading**: Courses, products, and offers are fetched from the API
3. **Redemption Process**: Users select items, system validates coin balance
4. **Transaction Processing**: Coins are deducted, redemption is recorded
5. **State Updates**: UI reflects new balance and redemption status
6. **Notification System**: Success/error messages provide user feedback

## External Dependencies

### Production Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM with PostgreSQL dialect
- **express**: Web framework for REST API endpoints
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/***: Headless UI component primitives
- **tailwindcss**: Utility-first CSS framework
- **react-hook-form**: Form validation and management
- **date-fns**: Date manipulation utilities

### Development Dependencies
- **vite**: Fast build tool with HMR support
- **typescript**: Static type checking
- **drizzle-kit**: Database schema management
- **tsx**: TypeScript execution for development

## Deployment Strategy

### Platform
- **Hosting**: Replit with autoscale deployment target
- **Database**: Neon Database serverless PostgreSQL
- **Build Process**: Vite builds frontend assets, esbuild bundles server code
- **Process Management**: Single Node.js process serving both API and static files

### Environment Configuration
- Development: Local development with HMR and hot reload
- Production: Optimized builds with static asset serving
- Database: Environment-based connection strings
- Port Configuration: Configurable ports for local and production environments

### Build Pipeline
1. Frontend build: `vite build` creates optimized static assets
2. Backend build: `esbuild` bundles server code with external dependencies
3. Asset serving: Express serves static files in production
4. Database migrations: Drizzle Kit manages schema changes

## Changelog
- June 25, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.